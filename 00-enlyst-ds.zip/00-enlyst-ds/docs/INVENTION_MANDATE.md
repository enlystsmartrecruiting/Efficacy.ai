# Invention Mandate — Enlystnow Ecosystem Craft (DS Canonical)

**Status:** Binding · DS v1.1.0 · Updated 2026-08-06
**Role:** the craft law — what every public page must contain and how it is audited. It does *not* define the ontology ([../VISION.md](../VISION.md)) or the token values ([../09-TOKENS.md](../09-TOKENS.md)).  
**Scope:** Every public **enlyst** practice page on `enlystnow.com` — home (elected), about (in progress), services, blog, contact — plus the `/ecosystem/` showcase and any future surface.  
**New here?** Start at [OPUS_HANDOFF.md](OPUS_HANDOFF.md).

> **★ Ontology:** [../VISION.md](../VISION.md) · [ENLYSTNOW_ONTOLOGY.md](ENLYSTNOW_ONTOLOGY.md) — Framework (constitution) → four practices create Ecosystem = Enlystnow (was Showreel). **Not** above the practices; **not** a consumer brand.  
> **Handoff:** `D:\ENLYST PVT\Enlyst\MANDATE_ECOSYSTEM_INVENTION.md`  
> **Craft assets:** [`../patterns/ecosystem-craft.css`](../patterns/ecosystem-craft.css) · [`../patterns/ecosystem-motion.js`](../patterns/ecosystem-motion.js) · preview [`../preview/ds-index.html`](../preview/ds-index.html)

---

## Ontology (locked)

```
Enlyst Framework (manifesto / living constitution)
    ├── opens gates → 18 doors
    └── four practices under it create Ecosystem = Enlystnow
        ├── legacy craft name: Showreel
        └── also appears as Board / Members (Tech · Marketing · HR · Healthcare · …)
```

Practice pages inherit **Enlystnow Ecosystem craft** while keeping **practice voice** (e.g. enlyst = Smart Recruiting). Never Holding. Never sell Enlystnow as a consumer brand on practice pages. Board face = synonym (see [ENLYSTNOW_ONTOLOGY.md](ENLYSTNOW_ONTOLOGY.md) § Board) — does not put Ecosystem above practices.

---

## North star

The craft bar is the **Enlystnow Ecosystem snapshot** (legacy shelf folder: *showreel*):

```
D:\Enlyst.Org\Enlystnow\Design-Libraries\06-showreel-snapshot\from-F-Enlystnow-showreel\
```

**Every public enlyst page** must meet or exceed **Enlystnow Ecosystem craft**. Brochure pages are not acceptable.

### Elected reference (home)

User **elected** home on **2026-08-04**: `D:\ENLYST PVT\Enlyst\home\index.html`  
Baseline: fonts, sky→void, `#2D5BE3`, nav-only wordmark, Ecosystem-level atmosphere.

### Machine-readable craft vocabulary

| File | Role |
|------|------|
| [`../patterns/craft-stack.json`](../patterns/craft-stack.json) | **Machine SoT** — pattern IDs, class contracts, page minimums, audit gate |
| [`../tokens/doors.js`](../tokens/doors.js) | **Machine SoT** — the 18 doors (name, slug, colour, pale, owner, status) with built-in uniqueness assertions |
| [`../patterns/ecosystem-craft.css`](../patterns/ecosystem-craft.css) | Live pattern implementation |
| [`../patterns/ecosystem-motion.js`](../patterns/ecosystem-motion.js) | Pattern behaviour |
| [`../patterns/craft-stack-glossary.css`](../patterns/craft-stack-glossary.css) | Human class map (documentary — declares no live styles) |
| [../VISION.md](../VISION.md) · [ENLYSTNOW_ONTOLOGY.md](ENLYSTNOW_ONTOLOGY.md) | Ontology |
| [GLOSSARY.md](GLOSSARY.md) | Every term, alias and forbidden word |
| [CONVENTIONS.md](CONVENTIONS.md) | File naming, import order, dependency graph, sync rules |

---

## Mandatory invention standard

### NOT allowed

- Brochure pages / incremental polish when invention asked  
- Ignoring 18-door colour system  
- Static dead pages (no orbs, reveals, door glow, live-pan, ticker where due)  
- day5 / archive photo recycling  
- Logo/wordmark after header on practice pages  
- **Holding** / mother-company framing  
- **Enlystnow as consumer brand** on practice pages  
- Instrument Serif weight > 400 on wordmark (y-ring bug)  
- Animated SVG dash spam if user rejected — UI motion still REQUIRED

### REQUIRED per page

- Atmosphere (`hero-atmosphere`) · section-owned palettes · custom graphics  
- Motion on UI / chrome / reveals · official door tokens · chrome theatre where fit  
- One job per section · match elected home chrome · **NOT elected** until approval  
- Locked 16-invention craft stack (§4)

---

## §4 Locked craft stack — 16 inventions

Source: Ecosystem snapshot (legacy `showreel.*` filenames on disk), elected `home/index.html` (2026-08-04).

> **Machine SoT:** [`../patterns/craft-stack.json`](../patterns/craft-stack.json). Pattern IDs, class contracts and page minimums are authoritative **there**. If this table and that file ever disagree, the JSON wins and this table is the bug. CSS: [`../patterns/ecosystem-craft.css`](../patterns/ecosystem-craft.css) · behaviour: [`../patterns/ecosystem-motion.js`](../patterns/ecosystem-motion.js) · live demos: [`../preview/ds-index.html`](../preview/ds-index.html).

### The universal baseline (every public practice page, no exceptions)

Patterns **2, 3, 14, 15, 16** — atmosphere, nav-only living brand, scroll reveal, section palettes, data-intensity. A page missing any one of these fails the audit regardless of page type.

### The sixteen

| # | Invention | Pattern ID | What it is | Required on |
|---|-----------|------------|------------|-------------|
| 1 | **Bento grid** | `bento` | 12-col weighted spans | Home · Services · Ecosystem |
| 2 | **Atmosphere plane** | `atmosphere` | dot grid + orbs / orbDrift | **Baseline — all** |
| 3 | **Living brand stage** | `living-brand-nav-only` | Nav-only wordmark; Instrument Serif 400; static mark | **Baseline — all** |
| 4 | **Chrome windows** | `chrome-windows` | live-card OS theatre | Home · Services · Ecosystem |
| 5 | **live-pan** | `live-pan` | Faux UI scroll inside chrome | Home · Services · Ecosystem |
| 6 | **Door planes** | `door-planes` | `data-door`, door-in, hover glow | Home · About · Ecosystem |
| 7 | **Telemetry strip** | `telemetry` | forge-tele numeric bands | Home · About · Services · Ecosystem |
| 8 | **Static system SVG** | `static-system-svg` | triad / kiln — geometry stays static | Home · About · Ecosystem |
| 9 | **Prose-cols** | `prose-cols` | Dual-column narrative | About · Blog · Contact |
| 10 | **Himat-Hikmat pills** | `himat-pills` | Courage / wisdom theatre | Home · About · Ecosystem |
| 11 | **Spine nodes** | `spine-nodes` | b-spine pulse steps | Home · About · Services · Ecosystem |
| 12 | **Portrait plane** | `portrait-plane` | Design-native portraits | Home · About |
| 13 | **Ticker** | `ticker` | Proof marquee | Home · Ecosystem |
| 14 | **Scroll reveal** | `scroll-reveal` | `.rv` → `.rv.on` | **Baseline — all** |
| 15 | **Section palettes** | `section-palettes` | cream / dark / sky / theatre, ≥3 bands | **Baseline — all** |
| 16 | **data-intensity** | `data-intensity` | calm / standard / cinematic + reduced-motion | **Baseline — all** (`<html>`) |

### Supporting chrome

sky→void · glass · glow utilities · Instrument Serif / Inter / DM Mono (400 only on the wordmark) · 18 door tokens · section header formula = `eyebrow-rule` kicker + serif H2 + lede.

### Page-type minimums (resolved — baseline already folded in)

| Page | Intensity | Required patterns | Optional |
|------|-----------|-------------------|----------|
| **Home** | `standard` | 1 · 2 · 3 · 4 · 5 · 6 · 7 · 8 · 10 · 11 · 12 · 13 · 14 · 15 · 16 | 9 |
| **About** | `standard` | 2 · 3 · 6 · 7 · 8 · 9 · 10 · 11 · 12 · 14 · 15 · 16 | 4 · 13 |
| **Services** | `standard` | 1 · 2 · 3 · 4 · 5 · 7 · 11 · 14 · 15 · 16 | 6 · 8 · 9 |
| **Blog** | `calm` | 2 · 3 · 9 · 14 · 15 · 16 | 7 · 13 |
| **Contact** | `calm` | 2 · 3 · 9 · 14 · 15 · 16 | 6 |
| **Ecosystem** (`/ecosystem/`) | `cinematic` | 1 · 2 · 3 · 4 · 5 · 6 · 7 · 8 · 10 · 11 · 13 · 14 · 15 · 16 | 9 · 12 |

Section-by-section briefs: [PAGE_SPECS.md](PAGE_SPECS.md).

---

## §5 Audit gate — a page ships only when every line is true

Machine mirror: `auditGate.checks` in [`../patterns/craft-stack.json`](../patterns/craft-stack.json).

**Structure**

- [ ] `<html>` carries `data-arm` **and** an explicit `data-intensity`
- [ ] Every pattern in the page's **required** row (§4) is present and rendering
- [ ] ≥ 3 distinct section palette bands
- [ ] One job per section — no section doing two jobs

**Brand**

- [ ] Wordmark in the **nav only** · Instrument Serif **400** · `font-synthesis: none`
- [ ] No duplicate logo or wordmark after the header
- [ ] Curly **y** verified by screenshot, not assumed
- [ ] `.framework-badge` does not animate
- [ ] Practice voice intact (enlyst = Smart Recruiting)

**Doors**

- [ ] Door elements carry `data-door`; each renders its **own** token colour
- [ ] No single shared accent standing in for multiple doors

**Motion**

- [ ] `prefers-reduced-motion: reduce` neutralises every animation
- [ ] System diagrams stay geometrically static
- [ ] `cinematic` used only on `/ecosystem/`

**Copy — forbidden strings**

- [ ] no "Holding" · no "mother company" / "mother platform" / "mother umbrella"
- [ ] no Enlystnow positioned above the practices
- [ ] no Enlystnow sold as a consumer brand
- [ ] no "Showreel" in public-facing copy (legacy disk paths only)

**Assets**

- [ ] Fonts loaded locally — no CDN font import in production ([FONT_LOADING.md](FONT_LOADING.md))
- [ ] No day5 / archive photo recycling
- [ ] Page remains **NOT elected** until the user approves

---

## Architecture (locked)

| Rule | Detail |
|------|--------|
| **Framework** | Manifesto / living constitution — opens 18 doors; enables Ecosystem |
| **Practices** | enlyst · enlysum · enlybiz · enlysoft — create Ecosystem together |
| **Ecosystem = Enlystnow** | Environment practices create (was Showreel); `/ecosystem/` |
| **enlystnow.com** | Public root for **enlyst** practice |
| **Never Holding** | Forbidden in public copy |
| **Never Enlystnow above practices** | Ontology forbids that stacking |
| **Wordmark** | Nav only; Instrument Serif **400 only** |
| **Doors** | Framework opens gates; unique colours |

See [ENLYSTNOW_ONTOLOGY.md](ENLYSTNOW_ONTOLOGY.md), [05-FRAMEWORK-ADMIN.md](../05-FRAMEWORK-ADMIN.md), [08-ECOSYSTEM-SHOWCASE.md](../08-ECOSYSTEM-SHOWCASE.md).

---

## File shelf

| Surface | Path |
|---------|------|
| Home **ELECTED** | `D:\ENLYST PVT\Enlyst\home\` |
| About (in progress, NOT elected) | `D:\ENLYST PVT\Enlyst\about\` |
| Ecosystem snapshot (north star) | `Design-Libraries\06-showreel-snapshot\from-F-Enlystnow-showreel\` |
| Design System (this package) | `Design-Libraries\00-enlyst-ds\` |
| Handoff mandate (external mirror) | `D:\ENLYST PVT\Enlyst\MANDATE_ECOSYSTEM_INVENTION.md` |

**Ownership split — no overlap:** this DS owns the *law* (ontology, tokens, patterns, page specs, audit gate). The external handoff mandate owns *live project state* (agent roster, page queue, election status). Neither restates the other; each links across.

---

## Agent onboarding ritual

1. Read [../VISION.md](../VISION.md) + [ENLYSTNOW_ONTOLOGY.md](ENLYSTNOW_ONTOLOGY.md) — Framework → practices → Ecosystem.  
2. Read this doc §4.  
3. Read `MANDATE_ECOSYSTEM_INVENTION.md`.  
4. Read elected home.  
5. Skim Ecosystem snapshot CSS/JS motion (legacy showreel folder).  
6. Open [`../preview/ds-index.html`](../preview/ds-index.html) — verify 16 patterns.  
7. Check page audits.  
8. Screenshot-verify y glyph + preview.

---

## Closing

Every enlyst public page is an **Enlystnow Ecosystem-class invention surface**, not a brochure. Ship invention, not shrugs.
