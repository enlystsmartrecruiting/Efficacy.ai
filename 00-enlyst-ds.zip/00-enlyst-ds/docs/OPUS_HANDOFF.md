# Handoff — Enlyst Ecosystem Design System

**Version:** 1.1.0 · **Date:** 2026-08-06
**Package:** `D:\Enlyst.Org\Enlystnow\Design-Libraries\00-enlyst-ds\`
**Status:** Complete and internally consistent. One open **asset** blocker (§7). Board-of-directors face documented (D-24).
**Audience:** any reviewer, implementer or agent arriving with no prior context.

**Read this file first. It is the only file you need before you can navigate the rest.**

---

## 1. What this is, in one paragraph

This is the design system for the Enlyst ecosystem: four professional-services practices operating under a shared constitution, plus eighteen sector "doors" they open onto. It defines the **ontology** (who relates to whom, and in which direction), the **tokens** (colour, type, space, motion), sixteen locked **craft patterns** that every public page must implement, **page specs** for each surface, and an **audit gate** that decides whether a page ships. It exists because the operator's public pages kept coming back as static brochures, and because the naming of the ecosystem's parts kept getting inverted. Both failure modes are now mechanically checkable.

**It is a specification package, not a build.** There is no bundler, no npm, no tests. Consumers are hand-authored static HTML pages that link two CSS files, optionally two JS files, and follow the patterns.

---

## 2. The ontology — the one thing to get right

Everything else follows from this. If you carry one paragraph away, carry this one.

> The **Enlyst Framework** is the manifesto and living constitution. It enables the ecosystem to thrive and **opens the gates to eighteen doors**. Under that constitution, four practices — **enlyst**, **enlysum**, **enlybiz**, **enlysoft** — operate. Together those practices **create** the **Ecosystem environment**. That environment **is Enlystnow**. Its legacy craft name was **Showreel**. Enlystnow may also be understood as a **board of directors / founders hub** with domain **Members** (Technology, Marketing, HR, Healthcare, …) — same referent, not a parent tier.

```mermaid
flowchart TB
  FW["Enlyst Framework<br/>manifesto · living constitution<br/>gold #C4A24A"]
  D18["18 doors<br/>gates · unique colour each"]
  P["Four practices<br/>enlyst · enlysum · enlybiz · enlysoft<br/>each its own host, accent and voice"]
  ECO["Ecosystem = Enlystnow<br/>the environment they create<br/>umbrella · entity · symbol · founders hub<br/>philosophy · ideology · signpost"]
  BOARD["Board / Members<br/>Technology · Marketing · HR · Healthcare · …"]
  SR["Showreel<br/>legacy craft name — disk paths only"]

  FW -->|opens the gates| D18
  FW -->|under which they operate| P
  P ==>|together create| ECO
  ECO -->|also appears as| BOARD
  ECO -.->|was called| SR
```

**The direction of creation runs upward from the practices.** Practices *create* the Ecosystem. The Ecosystem does not *contain* the practices. The board face does not reverse that.

### The statements that must never be contradicted

1. **Framework = manifesto and living constitution.** Not a method, not a Holding, not a consumer homepage, not a fifth practice.
2. **The four practices create the Ecosystem environment.** It is not a parent tier above them.
3. **Ecosystem = Enlystnow.** Identical referent, two names.
4. **Board / Members = Enlystnow institutional face.** Canonical synonym (founders hub). Does **not** replace Ecosystem = Enlystnow; does **not** put the ecosystem above the practices; does **not** invent practice brands for unmapped seats (esp. Healthcare).
5. **Never "Holding."** Also never "mother company", "mother platform" or "mother umbrella".
6. **Enlystnow is not a consumer brand.** Practice pages speak practice voice — on `enlystnow.com` that is *enlyst, Smart Recruiting*. **Domain ≠ brand.**

### Where "first" is easily misread

The Framework is first **constitutionally** — foundational, the thing the others operate under. It is *not* first commercially: it has no brand homepage and never outranks a practice root in the site hierarchy. Both statements are true simultaneously. See [GLOSSARY.md](GLOSSARY.md) §8.

---

## 3. Read order

**Do not read the numbered chapters in numeric order on a first pass.** The numbering is a reference sequence, not a learning sequence.

### Minimum path — understand the system (~20 minutes)

| # | File | Why |
|---|------|-----|
| 0 | **this file** | Orientation |
| 1 | [`../VISION.md`](../VISION.md) | The binding ontology. Step 0 of all other read orders. |
| 2 | [`GLOSSARY.md`](GLOSSARY.md) | Every term, alias, forbidden word, exact spelling |
| 3 | [`INVENTION_MANDATE.md`](INVENTION_MANDATE.md) | Craft law — the sixteen patterns, page minimums, §5 audit gate |
| 4 | [`../preview/ds-index.html`](../preview/ds-index.html) | **Open in a browser.** All sixteen patterns rendered live. |

### Full path — before implementing anything

| # | File | Why |
|---|------|-----|
| 5 | [`ENLYSTNOW_ONTOLOGY.md`](ENLYSTNOW_ONTOLOGY.md) | Canonical twin of VISION — doc-shaped, with the wrong-vs-right table |
| 6 | [`CONVENTIONS.md`](CONVENTIONS.md) | Layer model, dependency graph, import order, sync rules, authority order |
| 7 | [`../09-TOKENS.md`](../09-TOKENS.md) → [`../tokens/ecosystem.tokens.css`](../tokens/ecosystem.tokens.css) | Token index, then the values |
| 8 | [`FONT_LOADING.md`](FONT_LOADING.md) | The curly-y rule and **the one open blocker** |
| 9 | [`../07-DOORS.md`](../07-DOORS.md) → [`../tokens/doors.js`](../tokens/doors.js) | The eighteen doors and their registry |
| 10 | [`PAGE_SPECS.md`](PAGE_SPECS.md) | The page you are about to build |
| 11 | [`../patterns/craft-stack.json`](../patterns/craft-stack.json) | Machine contract — pattern IDs, classes, minimums, audit gate |
| 12 | [`../patterns/ecosystem-craft.css`](../patterns/ecosystem-craft.css) + [`../patterns/ecosystem-motion.js`](../patterns/ecosystem-motion.js) | The implementation |

### Reference — read when the question arises

`../01-TAXONOMY.md` · `../02-DOMAIN-MAP.md` · `../03-SEO-AND-REDIRECTS.md` · `../04-ENLYSTNOW-ADMIN.md` · `../05-FRAMEWORK-ADMIN.md` · `../06-OPERATING-ARMS.md` · `../08-ECOSYSTEM-SHOWCASE.md` · `../10-TYPE-AND-MOTION.md` · `../11-LOGOS-AND-MARKS.md` · `../12-COMPONENTS.md` · `../13-SURFACE-MATRIX.md` · [`DECISION_LOG.md`](DECISION_LOG.md) · [`../CHANGELOG.md`](../CHANGELOG.md)

---

## 4. File map — one line each

### Root — ontology and reference chapters

| File | Purpose |
|------|---------|
| `VISION.md` | **The binding ontology.** Unnumbered and deliberately first. |
| `README.md` | Index and map only. Holds no law; never wins a disagreement. |
| `CHANGELOG.md` | Version history. Current: 1.1.0. |
| `01-TAXONOMY.md` | Relationships + the `data-*` attribute contract |
| `02-DOMAIN-MAP.md` | Hosts, path map, canonical host rules, redirect plan |
| `03-SEO-AND-REDIRECTS.md` | Retiring the buried WordPress install; 301 discipline |
| `04-ENLYSTNOW-ADMIN.md` | Enlystnow / Ecosystem as institutional register; `data-register` semantics *(legacy filename)* |
| `05-FRAMEWORK-ADMIN.md` | The Framework as living constitution; gold; door 05 *(legacy filename)* |
| `06-OPERATING-ARMS.md` | The four practices — accents, hosts, spellings, legacy aliases *(legacy filename)* |
| `07-DOORS.md` | The eighteen doors — colours, pales, provenance, stewards, statuses |
| `08-ECOSYSTEM-SHOWCASE.md` | The `/ecosystem/` surface brief and naming chain |
| `09-TOKENS.md` | **Token index** — every family, hook and utility |
| `10-TYPE-AND-MOTION.md` | Type roles and the three motion tiers |
| `11-LOGOS-AND-MARKS.md` | Mark-per-surface rules and the wordmark law |
| `12-COMPONENTS.md` | Component grammar and the site shell |
| `13-SURFACE-MATRIX.md` | Every surface × identity × accent × intensity × indexing |

### `docs/` — law and handoff

| File | Purpose |
|------|---------|
| `OPUS_HANDOFF.md` | **This file.** Entry point, read order, file map, validation checklist. |
| `ENLYSTNOW_ONTOLOGY.md` | Canonical twin of `VISION.md`; wrong-vs-right framings |
| `INVENTION_MANDATE.md` | **Craft law** — §4 the sixteen patterns and page minimums, §5 the audit gate |
| `GLOSSARY.md` | Terms, aliases, forbidden words, exact spellings, disambiguation traps |
| `CONVENTIONS.md` | Layers, dependency graph, import order, naming, sync rules, authority order, versioning |
| `PAGE_SPECS.md` | Section-by-section spines for every surface |
| `FONT_LOADING.md` | Font standard, the curly-y mechanism, asset manifest, **open blocker** |
| `DECISION_LOG.md` | 25 resolved conflicts + 5 tracked open items |

### `tokens/` — layers 1–2

| File | Purpose |
|------|---------|
| `fonts.local.css` | `@font-face` only. Local files, no CDN. **Production contract.** |
| `ecosystem.tokens.css` | All custom properties + base typography utilities |
| `doors.js` | **Machine registry** for the eighteen doors, self-asserting uniqueness |
| `fonts.dev-fallback.css` | Preview-only CDN fallback. **Never ship.** |

### `patterns/` — layers 3–4

| File | Purpose |
|------|---------|
| `craft-stack.json` | **Machine SoT** — pattern IDs, classes, page minimums, audit gate |
| `ecosystem-craft.css` | The sixteen patterns, implemented |
| `ecosystem-motion.js` | Scroll reveal, intensity resolution, badge freeze |
| `craft-stack-glossary.css` | Human class map. Documentary — declares no live styles. |

### `preview/`, `seo/`, `_incoming/`

| Path | Purpose |
|------|---------|
| `preview/ds-index.html` | **Open this.** Live demo of all sixteen patterns + ontology + doors. `noindex`. |
| `seo/CPANEL-MESS-MAP.md`, `seo/CPANEL-WP-HUNT.md` | Findings on what the live host still serves |
| `seo/redirect-map.template.csv` | Redirect worksheet to fill from Search Console |
| `seo/sitemap-policy.md`, `seo/robots.examples.txt` | Sitemap and robots policy |
| `_incoming/**` | **Immutable reference paste.** Never imported, never edited. Still contains a Bunny `@import`. |

### External

| Path | Purpose |
|------|---------|
| `D:\ENLYST PVT\Enlyst\MANDATE_ECOSYSTEM_INVENTION.md` | Live project state — agent roster, page queue, election status. Points here for all law. |
| `D:\ENLYST PVT\Enlyst\home\index.html` | The **elected** home. Chrome baseline. |
| `Design-Libraries\06-showreel-snapshot\from-F-Enlystnow-showreel\` | Craft north star. Historical; its "mother platform" framing is superseded. |

---

## 5. The sixteen craft patterns

Every public page implements a defined subset. Machine contract: [`../patterns/craft-stack.json`](../patterns/craft-stack.json).

**Universal baseline — patterns 2, 3, 14, 15, 16 are mandatory on every practice page.** A page missing any one fails regardless of type.

| # | Pattern | ID | Core class |
|---|---------|----|------------|
| 1 | Bento grid | `bento` | `.bento` `.b-cell` `.b-c6` |
| 2 | Atmosphere plane | `atmosphere` | `.hero-atmosphere` `.hero-orb` |
| 3 | Living brand stage | `living-brand-nav-only` | `.brand-wordmark` |
| 4 | Chrome windows | `chrome-windows` | `.live-card` |
| 5 | live-pan | `live-pan` | `.live-pan` |
| 6 | Door planes | `door-planes` | `.door-plane` `[data-door]` |
| 7 | Telemetry strip | `telemetry` | `.forge-tele` |
| 8 | Static system SVG | `static-system-svg` | `.system-svg` |
| 9 | Prose-cols | `prose-cols` | `.prose-cols` |
| 10 | Himat-Hikmat pills | `himat-pills` | `.himat-pill` |
| 11 | Spine nodes | `spine-nodes` | `.b-spine-node` |
| 12 | Portrait plane | `portrait-plane` | `.portrait-plane` |
| 13 | Ticker | `ticker` | `.ticker-wrap` |
| 14 | Scroll reveal | `scroll-reveal` | `.rv` → `.rv.on` |
| 15 | Section palettes | `section-palettes` | `.band-cream/dark/sky/theatre` |
| 16 | data-intensity | `data-intensity` | `html[data-intensity]` |

### Page minimums

| Page | Intensity | Required | Optional |
|------|-----------|----------|----------|
| Home | `standard` | 1 2 3 4 5 6 7 8 10 11 12 13 14 15 16 | 9 |
| About | `standard` | 2 3 6 7 8 9 10 11 12 14 15 16 | 4 13 |
| Services | `standard` | 1 2 3 4 5 7 11 14 15 16 | 6 8 9 |
| Blog | `calm` | 2 3 9 14 15 16 | 7 13 |
| Contact | `calm` | 2 3 9 14 15 16 | 6 |
| `/ecosystem/` | `cinematic` | 1 2 3 4 5 6 7 8 10 11 13 14 15 16 | 9 12 |

---

## 6. Known constraints — deliberate, not oversights

Each of these looks like a defect until you know why. They are decisions.

| Constraint | Why |
|------------|-----|
| **The logo is static.** No spin, no glow, no transform on the brand mark. | Motion on the mark reintroduces the wordmark artefacts. Motion belongs to chrome, reveals and door theatre. `.framework-badge` never animates, even at `cinematic`. |
| **Instrument Serif at weight 400 only.** | The family ships one upright weight. Anything heavier is *synthesised*, and synthesis fills in the curl of the lowercase **y** in *enlyst*, rendering it as a solid ring. `font-synthesis: none` refuses the fake bold. [FONT_LOADING.md](FONT_LOADING.md) §2. |
| **No "Holding", ever.** | There is no parent company in this ontology. The word inverts the whole structure. |
| **"Showreel" only in disk paths.** | Retired public name. Kept in filenames because renaming the snapshot would destroy provenance. |
| **`enlystnow.com` root is enlyst, not Enlystnow.** | Domain ≠ brand. |
| **System diagrams never animate.** | Animated stroke-dash was explicitly rejected. UI and chrome motion is still required — the ban is on diagram geometry, not on the page. |
| **`cinematic` only on `/ecosystem/`.** | Practice pages use `calm` or `standard`. |
| **No day5 / archive photography.** | A rejected portrait batch. Portrait planes take design-native slots. |
| **Two filenames name retired concepts** (`04-…-ADMIN`, `06-OPERATING-ARMS`). | Frozen for link and sequence stability; each carries an in-file correction note. Renaming is a future major bump. D-19. |
| **Some rules appear in two CSS files.** | Wordmark, glass and `.framework-badge` are declared in both the token and pattern layers. Both read the same custom properties, so values cannot diverge — only `!important` enforcement differs. D-16. |
| **The door registry is `.js`, not `.json`.** | The preview runs from `file://`, where `fetch()` of local JSON is CORS-blocked. A `<script>` include works everywhere. D-23. |
| **`data-register` styles nothing.** | Semantic only, by design. It must never become a visual hierarchy that re-stacks the ontology. D-17. |
| **No build tooling.** | Consumers are hand-authored static pages. A build step would add a source of truth without adding value. |
| **Nothing is "elected" but the home page.** | *Elected* means user-approved. Only `home/index.html` (2026-08-04). No agent may self-declare election. |

---

## 7. The one open blocker

**The ten local `.woff2` font files do not exist on disk.**

`tokens/fonts.local.css` declares ten `@font-face` sources under `Design-Libraries/01-fonts/by-family/`. That directory is empty — the candidates found during the compile pass were unhydrated OneDrive stubs, recorded at the time in `Design-Libraries/INDEX.md`.

**What this means in practice.** Every surface currently falls back to Georgia, `system-ui` and `ui-monospace`. The wordmark renders in **Georgia**, whose `y` has a plain straight descender — so **the curly-y rule cannot be visually verified right now**, and any screenshot claiming to verify it is worthless until the binaries land. Type scale and letter-spacing were tuned for Instrument Serif, so fallback rendering will also look wrong and must not be judged as a design defect.

**What this is not.** It is not a specification gap. Weights, subsets, `unicode-range` values and paths are final and correct. The DS handles the situation explicitly rather than hiding it: `FONT_LOADING.md` §4 lists the exact ten filenames, `tokens/fonts.dev-fallback.css` lets the wordmark be inspected on the preview meanwhile, and the preview shows a runtime banner stating whether real Instrument Serif is active.

**To close it:** place the ten files at the manifest paths, reload the preview, confirm the banner flips to *loaded*, screenshot-verify the `y` at ≥400% zoom, remove any dev-fallback link, bump the changelog.

Everything else in this design system is complete. Other deferrals — logo election, HTML partials, `enlysum.com` acquisition, WordPress retirement — are scoped with written plans in [DECISION_LOG.md](DECISION_LOG.md) "Open items", not gaps.

---

## 8. Validation checklist

Run this mentally against the package. Every line should resolve without needing to ask a question.

### Ontology consistency

- [ ] `VISION.md`, `ENLYSTNOW_ONTOLOGY.md`, `README.md`, `01-TAXONOMY.md`, `05-FRAMEWORK-ADMIN.md`, `08-ECOSYSTEM-SHOWCASE.md`, `INVENTION_MANDATE.md`, `craft-stack.json`, the CSS headers, the preview and the external mandate all state the same chain in the same direction
- [ ] No file places Enlystnow or the Ecosystem above the practices
- [ ] "Holding", "mother company", "mother platform", "mother umbrella" appear only where explicitly labelled as forbidden or as superseded legacy
- [ ] "Showreel" appears only in disk paths or explicitly labelled as the legacy name
- [ ] The Framework is called a manifesto / living constitution everywhere, never merely a method
- [ ] `enlyst`, `enlysum`, `enlybiz`, `enlysoft` spelled identically throughout, lowercase

### Single source of truth

- [ ] Every concept has exactly one authority, and `CONVENTIONS.md` §6 resolves any tie
- [ ] Door data lives in `tokens/doors.js`; the CSS block and `07-DOORS.md` are declared mirrors with a written sync rule
- [ ] Craft patterns live in `craft-stack.json`; `INVENTION_MANDATE.md` §4 and the glossary CSS are declared mirrors
- [ ] `README.md` contains no law of its own
- [ ] Duplicated CSS rules (wordmark, glass, badge) read the same custom properties and are documented as intentional

### Tokens

- [ ] All 18 `--door-NN` values unique
- [ ] All 18 `--door-NN-pale` values unique *(this was broken — doors 06 and 11 collided at `#CCFBF1`; fixed, and now machine-asserted)*
- [ ] Every `-58` / `-26` alpha matches its base hex
- [ ] The token file is a superset of the snapshot baseline — no upstream token name resolves to nothing
- [ ] `--font-wordmark` exists and the wordmark rule pins weight 400 + `font-synthesis: none`
- [ ] `prefers-reduced-motion: reduce` neutralises every tier and every keyframe

### Craft stack

- [ ] All 16 patterns have: a JSON entry, CSS implementation, a glossary line, and a working preview demo
- [ ] Every JSON `classes` array matches the real selectors in `ecosystem-craft.css`
- [ ] Every page has explicit `required` and `optional` arrays — no ranges, no judgement calls
- [ ] The universal baseline is present in every page's required array
- [ ] `INVENTION_MANDATE.md` §4 tables and `craft-stack.json` agree row for row

### Structure and links

- [ ] Every relative link resolves (`docs/` files reach the root with `../`)
- [ ] `craft-stack.json` declares its path base
- [ ] Import order stated identically in `09-TOKENS.md`, `CONVENTIONS.md` and the token file header
- [ ] A version marker exists and matches between `CHANGELOG.md` and `craft-stack.json`
- [ ] Every doc states its role; no two docs claim the same role

### Preview

- [ ] Opens from `file://` with no broken CSS or JS path
- [ ] All 16 patterns render; the table of contents anchors all resolve
- [ ] The intensity switcher visibly changes motion
- [ ] The door grid renders all 18 in 18 distinct colours, from `doors.js`
- [ ] The font-status banner honestly reports whether Instrument Serif is loaded

### Completeness

- [ ] Ontology, tokens, patterns, page specs, glossary, conventions, font standard, decision log, changelog, handoff — all present
- [ ] The only open item is the font binaries, and it is documented in four places
- [ ] Every other deferral is scoped with a written plan

---

## 9. If you are about to build a page

1. Read `VISION.md` and `GLOSSARY.md`. Do not skip: most rework comes from getting a word wrong.
2. Find your page in [PAGE_SPECS.md](PAGE_SPECS.md). Take its spine literally — one job per section.
3. Link the four layers in order ([CONVENTIONS.md](CONVENTIONS.md) §3). Never reorder them.
4. Set `data-arm` and an explicit `data-intensity` on `<html>`.
5. Implement every pattern in your page's `required` array. Optional patterns are permitted but never sufficient.
6. Run the §5 audit gate in [INVENTION_MANDATE.md](INVENTION_MANDATE.md). Every line, not a sample.
7. Screenshot-verify the wordmark `y` — and note §7 above: until the font binaries land, that check cannot pass honestly.
8. Present it as **NOT elected**. Only the user elects.

---

## 10. Where the author expects challenge

Stated plainly rather than left for you to discover.

| Point | The argument for it |
|-------|---------------------|
| Doors 06–18 colours are DS-authored, not user-specified | The snapshot contains only five hexes. Inventing thirteen was necessary for the "unique colour per door" law to mean anything. All are unique in base and pale and hue-consistent with each door's family. Flagged per door via `source` in `doors.js`, and openly changeable. |
| Page minimums were tightened, not merely reconciled | Where the two contradicting statements disagreed, the stricter reading won. The standing instruction is invention over minimalism, so under-specifying was the greater risk. |
| A universal baseline was introduced, which no source document named | It is the only way to remove the whole class of "all pages" vs "this page's list" contradiction rather than patching three instances. Derived from patterns already marked "All practice pages". |
| `/ecosystem/` was added to the page minimums | It is the craft north star and the only `cinematic` surface, yet had no entry. Its absence was a gap, not a decision. |
| Legacy filenames were kept despite naming retired concepts | Link and sequence stability outweigh cosmetics; each carries an in-file correction. Renaming is queued as a major bump. |
| The door registry is `.js` | `file://` CORS. A `.json` file could not be consumed by the preview, which would have left the third copy of door data unsynchronised. |
| The dev font fallback uses a CDN, which the DS forbids | It is preview-only, marked never-ship in four places, and exists solely so the curly-y rule is inspectable before the binaries arrive. Production loading is unchanged. |

---

**Bottom line.** The ontology is locked and stated identically in every file — including the board/Members face as a synonym of Enlystnow (D-24). All sixteen patterns are specified, implemented and demonstrable. Every contradiction found in audit is resolved and recorded in [DECISION_LOG.md](DECISION_LOG.md). One asset — the font binaries — is genuinely missing, and the system says so in four places rather than pretending otherwise.

Preview: `D:\Enlyst.Org\Enlystnow\Design-Libraries\00-enlyst-ds\preview\ds-index.html`
