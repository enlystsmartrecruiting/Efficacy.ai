# Glossary — every term, alias and forbidden word

**Status:** Binding vocabulary · DS v1.1.0 · Updated 2026-08-06
**Role:** the single place that decides *what a word means* in this system. Where any other document uses a term loosely, this file decides.
**Ontology:** [../VISION.md](../VISION.md) · [ENLYSTNOW_ONTOLOGY.md](ENLYSTNOW_ONTOLOGY.md)

---

## 1. The five structural terms

These five carry the whole ontology. Getting one wrong inverts the system.

| Term | Definition | Never |
|------|------------|-------|
| **Enlyst Framework** | The **manifesto and living constitution**. It enables the Ecosystem to thrive and **opens the gates to eighteen doors**. Gold chrome (`#C4A24A`), door 05. | Not a Holding. Not a consumer brand site. Not a fifth practice. Not "just a method." |
| **Practice** | One of the four operating identities under the Framework: **enlyst**, **enlysum**, **enlybiz**, **enlysoft**. Each has its own host, accent and public voice. | Not "arms" in prose. Not sub-brands of a parent company. |
| **Ecosystem** | The **environment the four practices create together**, under the Framework. | Not a layer *above* the practices. Not a product. |
| **Enlystnow** | **Identical to Ecosystem.** Same environment, same referent. Umbrella, entity, symbol, founders hub, philosophy, ideology, signpost — and **board of directors** face with domain Members. | Not a consumer brand. Not above the practices. Not the identity of the `enlystnow.com` root. Not a Holding. |
| **Door** | One of eighteen sector gates the Framework opens. Each owns a unique colour and pale tint. | Not a generic accent chip. Not an org-chart box. Not a board Member seat. |

**The one line, memorised:**

> The Enlyst Framework is the manifesto and living constitution; it opens the gates to eighteen doors. Under it, four practices — enlyst, enlysum, enlybiz, enlysoft — operate, and together they create the Ecosystem environment. That environment is Enlystnow. Enlystnow may also be spoken as a board of directors / founders hub with domain Members — same referent, not a parent tier.

**The direction of creation is upward from the practices, not downward from Enlystnow.** Practices *create* the Ecosystem. The Ecosystem does not *contain* the practices. The board face does not reverse that.

---

## 1b. Board / Members (Enlystnow institutional face)

| Term | Definition | Never |
|------|------------|-------|
| **Board of directors** | Institutional face of Enlystnow / founders hub — domain seats speaking for the environment as a whole | A Holding · a layer above practices · a consumer brand site |
| **Member** | A domain seat on that board (Technology, Marketing, HR, Healthcare, …) | An invented practice brand · a substitute for a door |

| Seat | Practice / door link | Status |
|------|----------------------|--------|
| Member HR | ↔ enlyst (door 01 lineage) | Likely |
| Member Technology | ↔ enlysoft (door 04 lineage) | Likely |
| Member Marketing | ↔ enlybiz (door 03 lineage) | Likely |
| Member Healthcare | Board-domain seat only | **Open** — no practice brand / no door invented |
| Other Members | As applicable | Open |
| *(unassigned)* enlysum Finance | Practice exists; no Member named yet | Open |

Full rules: [ENLYSTNOW_ONTOLOGY.md](ENLYSTNOW_ONTOLOGY.md) § Board.

---

## 2. Legacy names and aliases

Every alias below is *permitted only in the stated place*. Using one outside that place is an audit failure.

| Term | Status | Permitted where | Canonical replacement |
|------|--------|-----------------|-----------------------|
| **Showreel** | Legacy craft name for the Ecosystem / Enlystnow layer | Disk paths and filenames only: `06-showreel-snapshot/`, `showreel.css`, `showreel.js`, and `_incoming/` snapshot pastes (`colors_and_type.css`, `motion_tokens.css`, …). Also permitted when explicitly labelling something as the legacy name. | **Ecosystem** / **Enlystnow Ecosystem** |
| **arm** / **operating arm** | Legacy noun for a practice | The `data-arm` **attribute** name; `--arm-*` **token** names; the legacy filename `06-OPERATING-ARMS.md`; legacy snapshot CSS | **practice** |
| **division** | Legacy noun for a practice | The `data-division` attribute (compatibility alias only) | **practice** |
| **admin arm** | **Wrong — retired** | Nowhere | Framework is a *constitution*; Enlystnow is the *Ecosystem environment* |
| `--hr-blue`, `--finance-green`, `--biz-amber`, `--tech-purple` | Legacy token aliases | Kept as aliases in the token file so snapshot CSS still resolves | `--arm-enlyst`, `--arm-enlysum`, `--arm-enlybiz`, `--arm-enlysoft` |
| **enlyst-hr** | Legacy folder name in raw source trees | Raw source trees only | **enlyst** |
| `MANDATE_SHOWREEL_INVENTION.md` | Legacy filename | Redirects to `MANDATE_ECOSYSTEM_INVENTION.md` | — |

---

## 3. Forbidden words and framings

These fail the audit wherever they appear in DS framing or public copy.

| Forbidden | Why | Say instead |
|-----------|-----|-------------|
| **Holding** | Implies a parent company owning the practices. The ontology has no such entity. | *the Ecosystem environment*, *the Framework* |
| **mother company** / **mother platform** / **mother umbrella** | Same inversion. Appears in legacy snapshot copy (`SECTORS.md` and historical pastes) — those files are superseded. | *the environment the practices create* |
| **Enlystnow above the practices** | Inverts the ontology. | *the practices create Enlystnow* |
| **Ecosystem as a tier / layer above** | Same inversion. | *Ecosystem is the field they create* |
| **"Welcome to Enlystnow"** | Sells Enlystnow as a consumer brand. | *"Experience the ecosystem"* → `/ecosystem/` |
| **Enlystnow the brand** (on practice pages) | Practice pages carry practice voice. | *enlyst — Smart Recruiting* |
| **Showreel** (in public copy) | Retired public name. | *Ecosystem* |
| **Framework as a homepage** | The Framework is constitutional, not a marketing surface. | *Framework method pages*, *door 05* |

---

## 4. Spelling — exact forms

| Correct | Wrong |
|---------|-------|
| `enlyst` | Enlyst (mid-sentence), ENLYST, enlyst-hr, Enlyst HR |
| `enlysum` | Enlysum (mid-sentence), EnlySum, Enlyst Sum, enlysum.com as current host |
| `enlybiz` | EnlyBiz, Enlybiz (mid-sentence), enlyBiz |
| `enlysoft` | EnlySoft, Enlysoft (mid-sentence), enlySoft |
| **Enlyst Framework** | enlyst framework, The Framework™, Enlyst framework |
| **Enlystnow** | EnlystNow, Enlyst Now, enlystnow (except as a hostname) |
| **Ecosystem** (capital E when naming the layer) | ecosystem-the-layer in lowercase where ambiguity results |
| **Himat-Hikmat** | Himat Hikmat, himat-hikmat (except as a slug), Himmat |
| **EnlyRecruit** | Enlyrecruit, enlyrecruit (except as a slug) |

Practice names are **lowercase** in running copy and in every attribute value. The only capitalised uses are proper-noun compounds (`Enlyst Framework`, `Enlyst Academy`) and sentence-initial position.

---

## 5. Craft vocabulary

| Term | Meaning |
|------|---------|
| **Enlystnow Ecosystem craft** | The craft bar every public page must meet: the 16 locked patterns. Named after the layer, not after a page. |
| **The 16 / locked craft stack** | The sixteen inventions in [INVENTION_MANDATE.md](INVENTION_MANDATE.md) §4, machine-defined in [`../patterns/craft-stack.json`](../patterns/craft-stack.json). |
| **Universal baseline** | Patterns 2, 3, 14, 15, 16 — mandatory on every practice page regardless of type. |
| **North star** | The Ecosystem snapshot at `06-showreel-snapshot/from-F-Enlystnow-showreel/` — the craft level to meet or exceed. |
| **Elected** | A page the user has explicitly approved. Only `home/index.html` is elected (2026-08-04). Nothing else may be called elected. |
| **Door theatre** | Door planes, maps and path cards — the surfaces where door colours and motion are expressed. |
| **Intensity tier** | `calm` / `standard` / `cinematic` via `data-intensity`. |
| **Band** | A section-owned palette region: `.band-cream`, `.band-dark`, `.band-sky`, `.band-theatre`. |
| **Register** | The voice a surface speaks in — `data-register`, semantic only. See [../04-ENLYSTNOW-ADMIN.md](../04-ENLYSTNOW-ADMIN.md). |
| **Curly-y bug** | Instrument Serif's descender ring artefact when a weight above 400 is synthesised. Fixed by weight 400 + `font-synthesis: none`. See [FONT_LOADING.md](FONT_LOADING.md). |
| **day5** | Shorthand for a rejected batch of archive portrait photography. Never reuse. |
| **Brochure page** | A static, motionless marketing page. The thing this DS exists to prevent. |

---

## 6. Concepts named in the doctrine

| Term | Meaning |
|------|---------|
| **Himat** | Courage. Paired with Hikmat in pattern 10; door 15. Rendered in Framework gold. |
| **Hikmat** | Wisdom. The counterweight to Himat. Rendered in enlyst blue. |
| **Startup Safe Zone** | Door 06 — four-month, four-practice build from chaos to operational backbone. |
| **The Fortress** | Door 07 — all-four retainer with shared institutional memory. |
| **Talent Forge** | Door 09 — graduate cohort programme closing into placements. |
| **Think → Act → Protect** | The triad rendered as a static system SVG (pattern 8). |
| **Kiln** | The pipeline metaphor for the Talent Forge phases, drawn as a static diagram. |

---

## 7. Surfaces

| Surface | What it is |
|---------|------------|
| `enlystnow.com/` | The **enlyst** practice root (Smart Recruiting). **Domain ≠ brand.** |
| `enlystnow.com/ecosystem/` | The Enlystnow Ecosystem showcase — cinematic, the craft north star. Not a brand homepage. |
| `enlystnow.com/paths/` | The path map: four practices + eighteen doors. |
| `enlystnow.com/framework/` | Optional Framework method pages. Never replaces the enlyst root. |
| `enlystnow.com/enlysum/` | Temporary enlysum home until `enlysum.com` is acquired. |
| `enlybiz.com` · `enlysoft.net` | The enlybiz and enlysoft practice hosts. |

---

## 8. Disambiguation traps

Four places where careful readers get confused. Answers are binding.

**"Is Enlystnow the same as the Ecosystem?"** Yes. Identical referent. Two names for one environment. Prefer "Ecosystem" or "Enlystnow Ecosystem" in craft docs. The **board / Members** face is a third *name for the same referent*, not a third entity.

**"If `enlystnow.com` is the domain, isn't Enlystnow the brand?"** No. Domain ownership is not brand identity. That root is the **enlyst** practice. Enlystnow is the environment, exhibited at `/ecosystem/`.

**"Is the Framework above the practices?"** Constitutionally, yes — it is the constitution they operate under, and it opens the doors. Commercially and visually, it is *not* a parent company and *not* a homepage that outranks practice roots. "First" here means foundational, not superior in a marketing hierarchy.

**"Does the board put Enlystnow above the practices?"** No. The board is how Enlystnow *appears* as founders hub / institutional register. Practices still *create* the environment. Member seats are domain faces, not a Holding org chart.

**"Eighteen doors, but four practices — are doors sub-brands of practices?"** No. The **Framework** opens every door. The `steward` column in [../07-DOORS.md](../07-DOORS.md) records which practice *operates* a door; it is not an ownership chain. Doors are also **not** board Member seats.
