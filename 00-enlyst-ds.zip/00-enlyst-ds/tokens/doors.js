/* ============================================================
   Enlyst Ecosystem DS — 18-door REGISTRY (single source of truth)
   ------------------------------------------------------------
   The Enlyst Framework, as living constitution, opens the gates to these
   eighteen doors. Each door owns a unique colour AND a unique pale tint.

   Why a .js file rather than .json: the DS preview runs from file:// where
   fetch() of a local .json is blocked by CORS. A plain <script> include works
   everywhere and stays readable as data. Node/CommonJS export is provided too.

   DECLARED MIRRORS — these must be regenerated or hand-checked against this
   file whenever a door changes (see ../docs/CONVENTIONS.md "Door sync rule"):
     1. tokens/ecosystem.tokens.css  --door-NN / -pale / -58 / -26 + [data-door] rules
     2. 07-DOORS.md                  human-readable table
   Name and ordering provenance: ../../06-showreel-snapshot/from-F-Enlystnow-showreel/SECTORS.md
   (that legacy file's "mother platform / umbrella" FRAMING is superseded by
   ../VISION.md — only the door names, order and purposes carry over).

   Colour provenance: doors 01–05 are verified against the Ecosystem snapshot
   token file (legacy showreel colors_and_type.css). Doors 06–18 are DS-authored.
   ============================================================ */
(function (root, factory) {
  var doors = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = doors;
  }
  if (root) {
    root.ENLYST_DOORS = doors;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  /* status: 'live' | 'preview' | 'research' | 'opening'
     owner:  which practice stewards the door ('framework' = constitution surface)
     source: 'snapshot' = hex verified against the Ecosystem snapshot
             'ds'       = authored in this design system */
  var DOORS = [
    { n: '01', slug: 'enlyst',                name: 'enlyst · HR & Talent',      color: '#2D5BE3', pale: '#EEF2FD', family: 'practice enlyst',            owner: 'enlyst',    status: 'live',     source: 'snapshot', purpose: 'Smart recruiting and people systems — acquisition to performance.' },
    { n: '02', slug: 'enlysum',               name: 'enlysum · Finance',         color: '#1A7A4A', pale: '#EBF5EF', family: 'practice enlysum',           owner: 'enlysum',   status: 'live',     source: 'snapshot', purpose: 'Accounting, payroll, tax, and fractional CFO clarity.' },
    { n: '03', slug: 'enlybiz',               name: 'enlybiz · Marketing',       color: '#C4620A', pale: '#FDF3EC', family: 'practice enlybiz',           owner: 'enlybiz',   status: 'live',     source: 'snapshot', purpose: 'Demand, brand, and revenue systems that convert visibility.' },
    { n: '04', slug: 'enlysoft',              name: 'enlysoft · Technology',     color: '#6B3FA0', pale: '#F2EEF9', family: 'practice enlysoft',          owner: 'enlysoft',  status: 'live',     source: 'snapshot', purpose: 'Cloud apps, infrastructure, automation, and product engineering.' },
    { n: '05', slug: 'framework',             name: 'Enlyst Framework',          color: '#C4A24A', pale: '#FAF4E2', family: 'constitution gold',          owner: 'framework', status: 'live',     source: 'snapshot', purpose: 'The living constitution itself as a surface — adoption and governance that keeps the practices coherent.' },
    { n: '06', slug: 'safe-zone',             name: 'Startup Safe Zone',         color: '#0D9488', pale: '#CCFBF1', family: 'method teal',                owner: 'framework', status: 'live',     source: 'ds',       purpose: 'Four-month four-practice build from chaos to operational backbone.' },
    { n: '07', slug: 'fortress',              name: 'The Fortress',              color: '#3D4F5F', pale: '#E8EEF2', family: 'steel',                      owner: 'framework', status: 'opening',  source: 'ds',       purpose: 'All-four retainer with shared institutional memory.' },
    { n: '08', slug: 'enlyrecruit',           name: 'EnlyRecruit',               color: '#1D4ED8', pale: '#DBEAFE', family: 'enlyst lineage (deeper)',    owner: 'enlyst',    status: 'preview',  source: 'ds',       purpose: 'Recruiter / employer / candidate OS — pipeline intelligence.' },
    { n: '09', slug: 'talent-forge',          name: 'Talent Forge',              color: '#D97706', pale: '#FEF3C7', family: 'forge amber',                owner: 'enlyst',    status: 'opening',  source: 'ds',       purpose: 'Graduate cohort programme that closes into real placements.' },
    { n: '10', slug: 'education',             name: 'Enlyst Education',          color: '#4F46E5', pale: '#E0E7FF', family: 'indigo',                     owner: 'enlysoft',  status: 'opening',  source: 'ds',       purpose: 'Learning layer spanning Academy, AI Academy and Talent Forge.' },
    { n: '11', slug: 'academy',               name: 'Enlyst Academy',            color: '#0F766E', pale: '#D2F0EC', family: 'academy teal',               owner: 'enlysoft',  status: 'opening',  source: 'ds',       purpose: 'Structured professional development with gate assessments.' },
    { n: '12', slug: 'ai-academy',            name: 'Enlyst AI Academy',         color: '#7C3AED', pale: '#EDE9FE', family: 'AI violet',                  owner: 'enlysoft',  status: 'opening',  source: 'ds',       purpose: 'Government-grade AI literacy (Intel IPA / GovTech track).' },
    { n: '13', slug: 'entrepreneurial-route', name: 'Entrepreneurial Route',     color: '#DB2777', pale: '#FCE7F3', family: 'route rose',                 owner: 'enlybiz',   status: 'opening',  source: 'ds',       purpose: 'Pathway for aspiring owners — ideas and Framework access, not CVs.' },
    { n: '14', slug: 'foundation',            name: 'Enlyst Foundation',         color: '#166534', pale: '#DCFCE7', family: 'research green',             owner: 'enlysum',   status: 'research', source: 'ds',       purpose: 'Ring-fenced non-commercial research mandate.' },
    { n: '15', slug: 'himat-hikmat',          name: 'Himat-Hikmat',              color: '#9A3412', pale: '#FFEDD5', family: 'courage saffron-earth',      owner: 'framework', status: 'research', source: 'ds',       purpose: 'Courage + wisdom doctoral research on Pakistan public education.' },
    { n: '16', slug: 'special-education',     name: 'Special Education',         color: '#8B5CF6', pale: '#F3E8FF', family: 'inclusive violet',           owner: 'enlysoft',  status: 'opening',  source: 'ds',       purpose: 'Inclusion by architecture — adjuster paths and accessible delivery.' },
    { n: '17', slug: 'govtech',               name: 'GovTech & Public Sector',   color: '#1E3A5F', pale: '#E2E8F0', family: 'institutional navy',         owner: 'enlysoft',  status: 'opening',  source: 'ds',       purpose: 'Public-institution systems, delivery tracks, and liability-aware tech.' },
    { n: '18', slug: 'unified-platform',      name: 'Unified Platform',          color: '#0E7490', pale: '#CFFAFE', family: 'platform cyan',              owner: 'enlysoft',  status: 'opening',  source: 'ds',       purpose: 'Single client surface across practices, memory, and workflows.' }
  ];

  /* Self-check — throws loudly rather than shipping a silent duplicate. */
  function assertUnique(key) {
    var seen = Object.create(null);
    for (var i = 0; i < DOORS.length; i++) {
      var v = String(DOORS[i][key]).toUpperCase();
      if (seen[v]) {
        throw new Error('ENLYST_DOORS: duplicate ' + key + ' "' + v + '" on doors ' + seen[v] + ' and ' + DOORS[i].n);
      }
      seen[v] = DOORS[i].n;
    }
  }
  assertUnique('n');
  assertUnique('slug');
  assertUnique('color');
  assertUnique('pale');
  if (DOORS.length !== 18) {
    throw new Error('ENLYST_DOORS: expected exactly 18 doors, found ' + DOORS.length);
  }

  return DOORS;
});
