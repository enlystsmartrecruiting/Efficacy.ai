# Find buried WordPress / mess on enlystnow.com (cPanel)

## What the live host shows right now (probe 2026-08-02)

| Check | Result |
|-------|--------|
| Live home | `https://www.enlystnow.com/` — **Showreel / “Mother umbrella · 18 sector doors”** (~50 KB), not WordPress HTML |
| DNS | `132.148.217.83` · NS `domaincontrol.com` (GoDaddy) |
| Apex | redirects to **www** |
| `/wp-login.php`, `/wp-admin/`, `/xmlrpc.php` | **410 Gone** (WP endpoints blocked or removed from web) |
| `/about/`, `/blog/`, `/services/`, `/contact/` | **404** (not currently serving) |
| Google | May still **list old WP URLs in the index** even when they now 404/410 — that is why 301s + GSC cleanup still matter |

So: the **old WP pages may already be dead on the web**, but the **files can still be buried in cPanel**, and Google can still show stale results until redirects + GSC cleanup.

---

## cPanel hunt — do this in order

### 1) Domains → document root

1. cPanel → **Domains** (or **Addon Domains** / **Subdomains**).  
2. Find `enlystnow.com` and `www.enlystnow.com`.  
3. Write down **Document Root** for each (examples):
   - `public_html`
   - `public_html/enlystnow.com`
   - `enlystnow.com`
   - something under `/home/USERNAME/...`

That folder is where the **current** Showreel/home lives. Everything else nearby is suspect clutter.

### 2) File Manager — open that document root

Look for **WordPress fingerprints**:

| Name | Meaning |
|------|---------|
| `wp-config.php` | WordPress install (smoking gun) |
| `wp-admin/` | WP admin |
| `wp-content/` | themes, plugins, uploads |
| `wp-includes/` | WP core |
| `xmlrpc.php` | WP |
| `wp-login.php` | WP login |
| `.htaccess` with `wordpress` / `RewriteRule` / `index.php` | WP permalinks |
| `wordpress/`, `wp/`, `old/`, `backup/`, `bk/`, `site-old/` | moved/old installs |

Also note what **is** the current site (likely):

- `index.html` (or `showreel` assets, `css/`, `js/`) — static Showreel home you see live

### 3) Softaculous / WP Toolkit / Applications

cPanel → **Softaculous Apps Installer** or **WordPress Toolkit** (name varies):

- List all WordPress installations.  
- Note path + URL for each.  
- Anything pointing at `enlystnow.com` (or old staging URL) = candidate to remove after backup.

### 4) Search entire home directory

File Manager → home (`/home/USERNAME`) → **Search**:

Search terms: `wp-config.php`, `wp-login.php`

Every hit is a WP tree. Write the full path for each.

### 5) Databases (phpMyAdmin)

cPanel → **MySQL Databases**:

- Note DBs named like `*_wp*`, `*wordpress*`, `*enlyst*`.  
- Match `DB_NAME` inside each `wp-config.php` you found.  
- Orphan DBs (no config) = leftover mess after deleted files.

### 6) Email yourself a listing (optional)

In cPanel **Terminal** (if enabled):

```bash
find $HOME -name wp-config.php 2>/dev/null
find $HOME -type d -name wp-admin 2>/dev/null
ls -la ~/public_html
ls -la ~/public_html/enlystnow.com 2>/dev/null
```

Paste the output here and we will mark keep vs delete vs redirect-only.

---

## What to send me (so we can clear safely)

Copy/paste or screenshot:

1. Document root path(s) for enlystnow.com / www  
2. List of files/folders in that root (top level only)  
3. Every path from `find … wp-config.php`  
4. Softaculous / WP Toolkit install list  
5. MySQL database names related to WP  

**Do not delete yet** until we label:

- **KEEP** — current Showreel/static home (soon: enlyst root + Ecosystem)  
- **ARCHIVE** — zip once to local/D: then remove from hosting  
- **DELETE** — clear leftover WP after archive + 301 plan  
- **REDIRECT** — GSC old URLs (about/blog/services) even if already 404  

---

## Why Google still shows old pages

Even with 404/410 today, Search Console can show **home / about / blog / services** until:

1. 301s point them at new URLs (preferred), or  
2. You use GSC “Remove outdated content” / wait for recrawl after sitemap cleanup.

Buried WP files in cPanel can also get re-exposed if an `.htaccess` or addon domain still points at an old folder — that is why we hunt disk, not only the live homepage.
