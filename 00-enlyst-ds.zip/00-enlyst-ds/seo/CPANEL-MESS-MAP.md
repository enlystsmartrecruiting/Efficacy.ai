# cPanel mess map (from your screenshots) — keep / archive / delete

**Do not delete yet.** Archive first, then delete in batches.

## What your screenshots prove

### A) WordPress is mostly inside a giant backup zip (not a clean live WP root)

Search `wp-config.php` found only:

- `/application_backups/oldbigbackup.zip/enlysoft.net/wp-config.php`
- `/application_backups/oldbigbackup.zip/enlybiz.com/wp-config.php`

Search `wp-admin` hits are also under that same zip (`…/oldbigbackup.zip/enlysoft.net/wp-admin/…`).

So the fired team left a **fat archive** of old WP sites for **enlysoft.net** and **enlybiz.com**. That zip is disk bloat + credential risk (`wp-config.php` has DB passwords). It is **not** what currently serves the Showreel home (live home is static HTML).

Also present in the account tree: a top-level **`wordpress/`** folder — treat as suspect until opened (may be empty remnant or second mess).

### B) Account root is a junk drawer of site attempts

Alongside `public_html` you have versioned clones and experiments:

- `.well-known.1` … `.well-known.4`
- `build` / `build.1` / `build 2`
- `fonts` / `fonts.1`
- `enlysoft-home` / `enlysoft-home.1`
- `enlyst-framework-index` / `.1` / zip copies
- `enlyst-home` / `enlyst-home 1`
- `elementor-home` / `elementor-home-1`
- `units` / `units.1`
- `Design System`, `Showreel`, `framework`, `application_backups`
- Domain-named folders scattered at account root: `enlybiz.com`, `enlysoft.net`, `enlyst.com`, `enlyst.net.enlystnow.com`, etc.

This is classic “upload everything to home directory” chaos — **not** a clean multi-site layout.

### C) `public_html` (and/or current docroot) has the pages Google cares about

Visible static pages (old / transitional site):

- `index.html` (home — currently the Showreel-style mother page live)
- `about.html`, `contact.html`, `philosophy.html`, `who-we-are.html`, `who-we-do.html` / `what-we-do.html`
- `.htaccess`
- folders: `css/`, `js/`, `framework/`, `enlybiz.com/`, `enlysoft.net/`, `enlyst-framework-index/`, `enlyst.com`, `Showreel` (or sibling), etc.

These HTML files are the **redirect targets source**: even if pretty URLs `/about/` 404, Google may still have older WP URLs; static `about.html` can also be indexed as `/about.html`.

### D) DNS (enlystnow.com zone)

| Record | Meaning |
|--------|---------|
| `@` + `www` → `132.148.217.83` | Main site on this cPanel box |
| `enlysum` → same IP | Good — matches temp Enlysum host plan (`enlysum.enlystnow.com` or path) |
| `wasim` → **two** A records (`15.197…` and `3.33…`) | Mess / leftover — not Enlyst site; clean later if unused |
| `autodiscover` → Outlook | Keep (email) |
| NS domaincontrol | GoDaddy DNS |

---

## Classification

### KEEP (production / needed)

| Item | Why |
|------|-----|
| `public_html` document root for enlystnow.com (confirm in Domains) | Live site |
| Current `index.html` + its `css/` `js/` assets that power the live home | Until Ecosystem cutover |
| `.htaccess` (edit, don’t wipe blind) | Redirects / www rules |
| SSL / `.well-known` **one** copy used by Let’s Encrypt | HTTPS |
| Email-related DNS (`autodiscover`) | Outlook |
| Addon docroots for `enlybiz.com` / `enlysoft.net` **if Domains still points there** | Other live arms — inspect before delete |

### ARCHIVE to local/D: then DELETE from hosting

| Item | Why |
|------|-----|
| `/application_backups/oldbigbackup.zip` | Entire old WP for enlybiz + enlysoft; huge; secrets inside |
| Any other zips under `application_backups/`, `backups/`, `wp-backups/` | Redundant |
| Account-root version piles: `*.1`, `build*`, `elementor-home*`, `enlyst-home*`, `units*`, duplicate `.well-known.*` | Team leftovers |
| Extra copies of `enlyst-framework-index*.zip` outside needed path | Dupes |
| Top-level `wordpress/` after you confirm it’s not a Domain docroot | Likely dead |

**Archive method:** File Manager → Compress/Download, or cPanel Backup → save to `D:\Enlyst.Org\Libraries\CursorWork\from-cPanel-YYYY-MM-DD\` then delete on server.

### REDIRECT (SEO) — do in `.htaccess` of live docroot

Map old indexed URLs → new enlyst paths (even if files later deleted):

| From (examples) | To |
|-----------------|-----|
| `/about.html`, `/about/`, `/about-us/` | new `/about/` or keep one about until new ships |
| `/services.html`, `/services/`, `/what-we-do.html`, `/who-we-do.html` | `/services/` or elected path |
| `/who-we-are.html` | `/about/` |
| `/contact.html`, `/contact/` | `/contact/` |
| Old WP permalinks from GSC | hub or matching page |
| `/showreel/` | `/ecosystem/` |

### DO NOT TOUCH until Domains map is written down

- Whatever folder **Domains → enlystnow.com → Document Root** points to  
- Whatever folder **enlybiz.com** / **enlysoft.net** document roots point to  
- `mail/`, `etc/`, `ssl/`, `logs/` system dirs  

---

## Cleanup order (safe)

1. **Screenshot Domains** page (every domain → document root). Send that next.  
2. Download `oldbigbackup.zip` to D: (or external drive).  
3. Download a zip of current live docroot (small insurance).  
4. Delete `application_backups/oldbigbackup.zip` from server after download verifies.  
5. Delete account-root `*.1` / build / elementor / duplicate well-known piles (not the live docroot).  
6. Open live `.htaccess` → add 301s for about/services/blog/html variants.  
7. GSC: request indexing of new hubs; monitor old URLs.  
8. Later: replace home with enlyst root + `/ecosystem/`.

---

## One-line verdict

The fired team left **(1)** a mega WP backup zip, **(2)** dozens of versioned experiment folders at account root, and **(3)** a static multi-HTML site in the web root that Google still knows about — while DNS already points `@`/`www`/`enlysum` at this same box.

---

## cPanel account card (dashboard)

| Field | Value |
|-------|--------|
| Primary domain | `enlystnow.com` |
| Home | `/home/aq09ws9hpfpo` |
| Shared IP | `132.148.217.83` |
| Addon domains | **2** / 10 → almost certainly `enlybiz.com` + `enlysoft.net` |
| Subdomains | **3** / 50 → includes `enlysum` (DNS) + likely others (`wasim` may be DNS-only) |
| Databases | **4** / 25 → more DBs than 2 live WP apps → leftovers |
| Disk | 1.65 GB / 50 GB · **18,398 files** |

Next click in cPanel: **Domains** (list every domain → document root path).

### `public_html` inventory (your File Manager screenshot)

Path: `/home/aq09ws9hpfpo/public_html` — **primary docroot for enlystnow.com**

| Name | Role | Action |
|------|------|--------|
| `index.html` | Live home (Showreel / mother page) | KEEP until Ecosystem cutover; then replace |
| `about.html` | Old/static about | KEEP for now → later 301 `/about.html` → new about |
| `contact.html` | Old/static contact | KEEP → later 301 |
| `philosophy.html` | Old/static | KEEP → later 301 or hub |
| `.htaccess` | Apache rules | KEEP (edit for 301s) |
| `css/`, `js/`, `ds/`, `framework/` | Assets for current static home | KEEP with home |
| `enlybiz.com/` | Likely **addon domain docroot** for enlybiz | KEEP until Domains confirms |
| `enlysoft.net/` | Likely **addon domain docroot** for enlysoft | KEEP until Domains confirms |
| `enlybiz/` | Extra folder (not `.com`) | ARCHIVE later — probably dupe clutter |
| `enlyst-framework-index/` + `.zip` | Experiment / zip dump | ARCHIVE then delete zip from web root |
| `enlysurn.enlystnow.com/` | Typo subdomain folder? (enly**sum**?) | Check Domains/subdomains — don’t delete until confirmed |
| `.well-known/` | SSL | KEEP |

No `wp-admin` / `wp-content` in this `public_html` root — enlystnow.com here is **static HTML**, not live WordPress.

## Installatron update (your latest screenshots)

| App in Installatron | Domain | Size | Backups in tool | Status |
|---------------------|--------|------|-----------------|--------|
| Enlybiz… | `www.enlybiz.com` | ~169 MB files + 7 MB DB | **2** | Live + **error** |
| Enlysoft… | `www.enlysoft.net` | ~90 MB files + 2 MB DB | **0** | Live + **error** |
| *(none)* | **enlystnow.com** | — | — | **Not an Installatron WP app** |

**Error on both:** `failed_application_config_doesnotexist` — Installatron cannot read `wp-config.php` at the path it thinks the app lives. So **in-app Backup/Update are broken** until the path is fixed or the app is detached.

That matches File Manager: real `wp-config.php` copies were found **inside** `application_backups/oldbigbackup.zip/…`, not where Installatron expects.

### Download order before any uninstall/delete

1. **Installatron → My Backups (2)** — download both listed backups to your PC/D: (these are the tool’s stored backups for enlybiz; may still download even if live “Backup” button fails).  
2. **File Manager → `application_backups/oldbigbackup.zip`** — download this whole zip (contains enlybiz + enlysoft WP trees).  
3. **File Manager** — select current **enlystnow.com document root** (likely `public_html` or similar) → Compress → Download (captures Showreel/static HTML Google sees).  
4. Only after those three are on D: and you can open/verify the zips → then consider Detach/Uninstall or file deletes.

### Do not yet

- Uninstall either Installatron app  
- Delete `oldbigbackup.zip`  
- Wipe `public_html`  

### After backups are safe

- Fix or **Detach** broken Installatron entries (they’re ghost managers).  
- Rebuild enlybiz / enlysoft later as clean sites; enlystnow.com stays static → enlyst + Ecosystem plan.
