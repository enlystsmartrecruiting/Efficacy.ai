# Sitemap policy

## Per host

| Host | Sitemap URL | Must include |
|------|-------------|--------------|
| enlystnow.com | `https://enlystnow.com/sitemap.xml` | `/`, key enlyst pages, `/paths/`, `/ecosystem/`, `/enlysum/` (while temp), public door pages on this host |
| enlybiz.com | `https://enlybiz.com/sitemap.xml` | enlybiz public pages only |
| enlysoft.net | `https://enlysoft.net/sitemap.xml` | enlysoft public pages only |

## Rules

1. Only **200** canonical URLs.  
2. No HTTP, no www duplicates, no redirected URLs.  
3. No `noindex` URLs.  
4. After major cuts: replace sitemap, resubmit in GSC, remove obsolete sitemap indexes.  
5. When `enlysum.com` launches: remove `/enlysum/` URLs from enlystnow.com sitemap after 301s are live.
