﻿ENLYSTNOW MOTHER — ECOSYSTEM CRAFT BASE (formerly Showreel)
================================

Canonical mother umbrella page (locked by direction Jul 2026):

  D:\Enlystnow\ecosystem\

This is the real Enlystnow mother surface — eighteen sector doors,
Framework, four operating arms. Keep the build’s current visual language
(division accents + living mark). Do not force a gold-only mother chrome.

Sector map: SECTORS.md

How to preview
--------------
  cd D:\Enlystnow\ecosystem
  npx --yes serve . -p 3456
  → http://127.0.0.1:3456/

cPanel package
--------------
See: D:\Enlyst.Org\Enlystnow\websites\deploy-showreel-mother\
     and CPANEL_UPLOAD.md in that folder.

Note on deploy-72/enlystnow
---------------------------
Older multi-page umbrella archive. Not the locked mother base.
HR practice material remains separate (enlyst HR / _live-home archive).

---
RENAMED on disk: 2026-08-02
Was: D:\Enlystnow\showreel
Now: D:\Enlystnow\ecosystem
Public URL: https://enlystnow.com/ecosystem/
Asset filenames css/showreel.css and js/showreel.js kept (relative links unchanged).
